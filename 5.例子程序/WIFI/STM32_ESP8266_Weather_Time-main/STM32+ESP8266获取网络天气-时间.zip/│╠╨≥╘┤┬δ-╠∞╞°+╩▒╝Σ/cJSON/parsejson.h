#ifndef __PARSEJSON_
#define __PARSEJSON_

#include "sys.h"

void parse_3days_weather(void);
void parse_now_weather(void);

#endif



